import argparse
import json
import re
import threading
import time
from collections import deque

from flask import Flask, jsonify, request
import serial


LOG_LIMIT = 500

app = Flask(__name__)
ser = None
serial_lock = threading.Lock()
logs = deque(maxlen=LOG_LIMIT)
state = {
    "connected": False,
    "port": "",
    "last_seq": None,
    "boot_id": None,
    "send_time_ms": None,
    "temperature": None,
    "humidity": None,
    "soil_moisture": None,
    "soil_raw": None,
    "rain_level": None,
    "rain_raw": None,
    "wifi_signal": None,
    "wifi_ip": None,
    "wifi_gateway": None,
    "lorawan_retry_count": None,
    "wifi_retry_count": None,
    "uplink_freq": None,
    "uplink_dr": None,
    "downlink_bytes": None,
    "servo_angle": None,
    "motor_status": "unknown",
    "led_status": "unknown",
    "lorawan": "unknown",
    "mqtt": "unknown",
    "mqtt_topic": "",
    "mqtt_payload": "",
    "downlink_topic": "",
    "downlink_payload": "",
    "downlink_time": "",
    "downlink_action": "",
    "mode": "auto",
    "paused": False,
    "interval_s": None,
    "link_mode": "auto",
    "lorawan_sent": 0,
    "lorawan_ok": 0,
    "lorawan_failed": 0,
    "mqtt_sent": 0,
    "mqtt_ok": 0,
    "mqtt_failed": 0,
    "last_line": "",
    "last_update": None,
}


def add_log(line):
    ts = time.strftime("%H:%M:%S")
    item = {"time": ts, "line": line}
    logs.append(item)
    state["last_line"] = line
    state["last_update"] = ts
    parse_state(line)


def describe_downlink_payload(payload):
    text = payload.strip()
    lower = text.lower()

    def normalize(value):
        return str(value).strip().lower().replace("_", " ").replace("-", " ")

    def from_target_value(target, value):
        target = normalize(target)
        value = normalize(value)
        if target in ("led", "light"):
            if value in ("on", "1", "true", "start", "run", "running"):
                return "led on requested"
            if value in ("off", "0", "false", "stop", "stopped"):
                return "led off requested"
        if target in ("motor", "servo"):
            if value in ("on", "1", "true", "start", "run", "running"):
                return "motor start requested"
            if value in ("off", "0", "false", "stop", "stopped"):
                return "motor stop requested"
        return ""

    if lower in ("led on", "led off", "motor on", "motor off", "servo on", "servo off"):
        return lower.replace("servo", "motor") + " requested"

    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        return "received payload"

    cmd = normalize(data.get("cmd", data.get("command", "")))
    value = normalize(data.get("value", data.get("state", "")))
    target = normalize(data.get("target", ""))

    if cmd in ("led on", "led off", "motor on", "motor off", "servo on", "servo off"):
        return cmd.replace("servo", "motor") + " requested"

    result = from_target_value(cmd, value)
    if result:
        return result

    result = from_target_value(target, value)
    if result:
        return result

    return "non-command payload"

def describe_lorawan_downlink_hex(hex_text):
    parts = hex_text.strip().split()
    try:
        data = [int(part, 16) for part in parts]
    except ValueError:
        return "received LoRaWAN bytes"

    if len(data) >= 3 and data[0] == 0xA5:
        target = data[1]
        value = data[2]
        if target == 0x01:
            return "led on requested" if value else "led off requested"
        if target == 0x02:
            return "motor start requested" if value else "motor stop requested"
        return f"unsupported target {target}"

    return "received LoRaWAN bytes"


def parse_state(line):
    lorawan_down_hex = re.search(r"\[LoRaWAN/DOWN\] hex=(.+)", line)
    if lorawan_down_hex:
        state["downlink_topic"] = "LoRaWAN FPort 2"
        state["downlink_payload"] = lorawan_down_hex.group(1)
        state["downlink_time"] = time.strftime("%H:%M:%S")
        state["downlink_action"] = describe_lorawan_downlink_hex(lorawan_down_hex.group(1))
        return

    lorawan_down_text = re.search(r"\[LoRaWAN/DOWN\] text=(.*)", line)
    if lorawan_down_text:
        text = lorawan_down_text.group(1)
        state["downlink_topic"] = "LoRaWAN FPort 2"
        state["downlink_payload"] = text
        state["downlink_time"] = time.strftime("%H:%M:%S")
        state["downlink_action"] = describe_downlink_payload(text)
        return

    if "[LoRaWAN/DOWN] unsupported command" in line:
        state["downlink_topic"] = "LoRaWAN FPort 2"
        state["downlink_action"] = "unsupported LoRaWAN command"
        state["downlink_time"] = time.strftime("%H:%M:%S")
        return

    downlink_topic = re.search(r"\[MQTT/DOWN\] topic=(.+)", line)
    if downlink_topic:
        state["downlink_topic"] = downlink_topic.group(1)
        state["downlink_time"] = time.strftime("%H:%M:%S")
        state["downlink_action"] = "received topic"
        return

    downlink_payload = re.search(r"\[MQTT/DOWN\] payload=(.*)", line)
    if downlink_payload:
        payload = downlink_payload.group(1)
        state["downlink_payload"] = payload
        state["downlink_time"] = time.strftime("%H:%M:%S")
        state["downlink_action"] = describe_downlink_payload(payload)
        return

    if "[MQTT/DOWN] unsupported command" in line or "[MQTT/DOWN] ignored non-command payload" in line:
        state["downlink_action"] = "ignored non-command payload"
        state["downlink_time"] = time.strftime("%H:%M:%S")
        return

    sensor = re.search(
        r"\[SENSOR\] temp=([0-9.-]+) humi=([0-9.-]+) soil=([0-9.-]+)% raw=(\d+) rain=([0-9.-]+)% raw=(\d+)",
        line,
    )
    if sensor:
        state["temperature"] = float(sensor.group(1))
        state["humidity"] = float(sensor.group(2))
        state["soil_moisture"] = float(sensor.group(3))
        state["soil_raw"] = int(sensor.group(4))
        state["rain_level"] = float(sensor.group(5))
        state["rain_raw"] = int(sensor.group(6))
        return

    wifi_only = re.search(
        r"\[WiFiOnly\] uplink seq=(\d+) boot=(\d+) send_ms=(\d+) temp=([0-9.-]+) humi=([0-9.-]+) soil=([0-9.-]+)% raw=(\d+) rain=([0-9.-]+)% raw=(\d+)",
        line,
    )
    if wifi_only:
        state["last_seq"] = int(wifi_only.group(1))
        state["boot_id"] = int(wifi_only.group(2))
        state["send_time_ms"] = int(wifi_only.group(3))
        state["temperature"] = float(wifi_only.group(4))
        state["humidity"] = float(wifi_only.group(5))
        state["soil_moisture"] = float(wifi_only.group(6))
        state["soil_raw"] = int(wifi_only.group(7))
        state["rain_level"] = float(wifi_only.group(8))
        state["rain_raw"] = int(wifi_only.group(9))
        state["lorawan"] = "join waiting"
        return

    servo = re.search(r"\[SERVO\] angle=(\d+) status=(\w+)", line)
    if servo:
        state["servo_angle"] = int(servo.group(1))
        state["motor_status"] = servo.group(2)
        state["downlink_action"] = f"motor {servo.group(2)}"
        return

    led = re.search(r"\[LED\] status=(\w+)", line)
    if led:
        state["led_status"] = led.group(1)
        state["downlink_action"] = f"led {led.group(1)}"
        return

    uplink = re.search(
        r"\[LoRaWAN\] uplink seq=(\d+) boot=(\d+) send_ms=(\d+) retry=(\d+) temp=([0-9.-]+) humi=([0-9.-]+)(?: soil=([0-9.-]+)% raw=(\d+))?(?: rain=([0-9.-]+)% raw=(\d+))?(?: motor=(\w+) servo_angle=(\d+) led=(\w+) signal=(-?\d+))?",
        line,
    )
    if uplink:
        state["last_seq"] = int(uplink.group(1))
        state["boot_id"] = int(uplink.group(2))
        state["send_time_ms"] = int(uplink.group(3))
        state["lorawan_retry_count"] = int(uplink.group(4))
        state["temperature"] = float(uplink.group(5))
        state["humidity"] = float(uplink.group(6))
        if uplink.group(7) is not None:
            state["soil_moisture"] = float(uplink.group(7))
            state["soil_raw"] = int(uplink.group(8))
        if uplink.group(9) is not None:
            state["rain_level"] = float(uplink.group(9))
            state["rain_raw"] = int(uplink.group(10))
        if uplink.group(11) is not None:
            state["motor_status"] = uplink.group(11)
            state["servo_angle"] = int(uplink.group(12))
            state["led_status"] = uplink.group(13)
            state["wifi_signal"] = int(uplink.group(14))
        state["lorawan"] = "sending"
        state["lorawan_sent"] += 1
        return

    send_state = re.search(r"\[LoRaWAN\] sendReceive state=(-?\d+)", line)
    if send_state:
        code = int(send_state.group(1))
        if code >= 0:
            state["lorawan"] = "ok"
            state["lorawan_ok"] += 1
        else:
            state["lorawan"] = "failed"
            state["lorawan_failed"] += 1
        return

    if "[LoRaWAN] OTAA join start" in line:
        state["lorawan"] = "joining"
        return

    if "activateOTAA failed" in line:
        state["lorawan"] = "join failed"
        return

    uplink_detail = re.search(r"\[LoRaWAN\] uplink freq=([0-9.]+) MHz DR=(\d+)", line)
    if uplink_detail:
        state["uplink_freq"] = float(uplink_detail.group(1))
        state["uplink_dr"] = int(uplink_detail.group(2))
        return

    downlink = re.search(r"\[LoRaWAN\] downlink bytes=(\d+)", line)
    if downlink:
        state["downlink_bytes"] = int(downlink.group(1))
        return

    wifi = re.search(
        r"\[WiFi\] status=\d+ IP=([0-9.]+) gateway=([0-9.]+) rssi=(-?\d+)",
        line,
    )
    if wifi:
        state["wifi_ip"] = wifi.group(1)
        state["wifi_gateway"] = wifi.group(2)
        state["wifi_signal"] = int(wifi.group(3))
        return

    if "[MQTT] connected" in line:
        state["mqtt"] = "connected"
        return

    mqtt_topic = re.search(r"\[MQTT\] publish topic=(.+)", line)
    if mqtt_topic:
        state["mqtt_topic"] = mqtt_topic.group(1)
        state["mqtt_sent"] += 1
        return

    mqtt_payload = re.search(r"\[MQTT\] payload=(.+)", line)
    if mqtt_payload:
        payload = mqtt_payload.group(1)
        state["mqtt_payload"] = payload
        try:
            data = json.loads(payload)
            state["temperature"] = data.get("temperature", state["temperature"])
            state["humidity"] = data.get("humidity", state["humidity"])
            state["soil_moisture"] = data.get("soil_moisture", state["soil_moisture"])
            state["rain_level"] = data.get("rain_level", state["rain_level"])
            state["servo_angle"] = data.get("servo_angle", state["servo_angle"])
            state["motor_status"] = data.get("motor_status", state["motor_status"])
            state["led_status"] = data.get("led_status", state["led_status"])
            state["wifi_signal"] = data.get("signal", state["wifi_signal"])
            raw = data.get("raw") or {}
            state["boot_id"] = raw.get("boot_id", state["boot_id"])
            state["last_seq"] = raw.get("seq", state["last_seq"])
            state["send_time_ms"] = raw.get("send_time_ms", state["send_time_ms"])
            state["wifi_retry_count"] = raw.get("wifi_retry_count", state["wifi_retry_count"])
            state["soil_raw"] = raw.get("soil_raw", state["soil_raw"])
            state["rain_raw"] = raw.get("rain_raw", state["rain_raw"])
        except json.JSONDecodeError:
            pass
        return

    mqtt_ok = re.search(r"\[MQTT\] publish OK retry=(\d+)", line)
    if mqtt_ok:
        state["mqtt"] = "published"
        state["wifi_retry_count"] = int(mqtt_ok.group(1))
        state["mqtt_ok"] += 1
        return

    mqtt_failed = re.search(r"\[MQTT\] publish failed retry=(\d+)", line)
    if mqtt_failed:
        state["mqtt"] = "failed"
        state["wifi_retry_count"] = int(mqtt_failed.group(1))
        state["mqtt_failed"] += 1
        return

    if "[MQTT] connect failed" in line:
        state["mqtt"] = "failed"
        return

    ctrl = re.search(
        r"\[CTRL\] status mode=(\w+) paused=(\w+) interval_s=(\d+) manual_temp=([0-9.-]+) manual_humi=([0-9.-]+)(?:.*link_mode=(\w+))?",
        line,
    )
    if ctrl:
        state["mode"] = ctrl.group(1)
        state["paused"] = ctrl.group(2) == "true"
        state["interval_s"] = int(ctrl.group(3))
        state["temperature"] = float(ctrl.group(4))
        state["humidity"] = float(ctrl.group(5))
        if ctrl.group(6):
            state["link_mode"] = ctrl.group(6)
        return

    if "[CTRL] mode manual" in line:
        state["mode"] = "manual"
    elif "[CTRL] mode auto" in line:
        state["mode"] = "auto"
    elif "[CTRL] paused" in line:
        state["paused"] = True
    elif "[CTRL] resumed" in line:
        state["paused"] = False
    elif "[LINK] demo mode force WiFi fallback" in line:
        state["link_mode"] = "force_wifi"
    elif "[LINK] demo mode auto" in line:
        state["link_mode"] = "auto"
    elif "led=" in line:
        led_status = re.search(r"led=(\w+)", line)
        if led_status:
            state["led_status"] = led_status.group(1)


def serial_reader():
    global ser
    while True:
        try:
            line = ser.readline().decode("utf-8", errors="replace").strip()
            if line:
                add_log(line)
        except Exception as exc:
            state["connected"] = False
            add_log(f"[CONSOLE] serial read error: {exc}")
            time.sleep(1)


def send_command(command):
    if not command.endswith("\n"):
        command += "\n"
    with serial_lock:
        ser.write(command.encode("utf-8"))
        ser.flush()
    add_log(f"[CONSOLE] sent command: {command.strip()}")


@app.route("/")
def index():
    return """
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>EoRa-S3 Console</title>
  <style>
    :root { color-scheme: dark; font-family: Segoe UI, Arial, sans-serif; }
    body { margin: 0; background: #101318; color: #edf2f7; }
    header { padding: 18px 24px; border-bottom: 1px solid #263241; background: #151a21; }
    h1 { margin: 0; font-size: 22px; }
    main { padding: 20px 24px; display: grid; grid-template-columns: 390px 1fr; gap: 18px; }
    section { background: #171d25; border: 1px solid #293544; border-radius: 8px; padding: 16px; }
    .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
    .grid3 { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; }
    .card { background: #111720; border: 1px solid #253140; border-radius: 6px; padding: 12px; }
    .label { color: #95a3b5; font-size: 12px; }
    .value { font-size: 22px; margin-top: 4px; overflow-wrap: anywhere; }
    .small { font-size: 14px; color: #cbd5e1; }
    button { box-sizing: border-box; width: 100%; border: 0; border-radius: 6px; background: #2563eb; color: #edf2f7; cursor: pointer; font-weight: 700; padding: 10px; }
    button.secondary { background: #334155; }
    .row { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-top: 10px; }
    .row2 { display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; margin-top: 10px; }
    pre { margin: 0; height: 560px; overflow: auto; white-space: pre-wrap; font-size: 13px; line-height: 1.45; }
    .ok { color: #22c55e; }
    .bad { color: #f87171; }
    .muted { color: #94a3b8; }
  </style>
</head>
<body>
  <header>
    <h1>EoRa-S3 Sensor Monitor</h1>
    <div class="muted">Real-time sensor data + transmission serial log</div>
  </header>
  <main>
    <div>
      <section>
        <h2>Sensor Data</h2>
        <div class="grid">
          <div class="card"><div class="label">Seq</div><div id="seq" class="value">-</div></div>
          <div class="card"><div class="label">Boot ID</div><div id="boot" class="value">-</div></div>
          <div class="card"><div class="label">Air Temp</div><div id="temp" class="value">-</div></div>
          <div class="card"><div class="label">Air Humi</div><div id="humi" class="value">-</div></div>
          <div class="card"><div class="label">Soil Moisture</div><div id="soil" class="value">-</div><div id="soilRaw" class="small">raw -</div></div>
          <div class="card"><div class="label">Rain Level</div><div id="rain" class="value">-</div><div id="rainRaw" class="small">raw -</div></div>
        </div>
      </section>
      <section style="margin-top:18px">
        <h2>Send Status</h2>
        <div class="grid">
          <div class="card"><div class="label">LoRaWAN</div><div id="lorawan" class="value">-</div></div>
          <div class="card"><div class="label">MQTT</div><div id="mqtt" class="value">-</div></div>
          <div class="card"><div class="label">LoRa Freq / DR</div><div id="lorawanRadio" class="value small">-</div></div>
          <div class="card"><div class="label">Downlink</div><div id="downlink" class="value">-</div></div>
          <div class="card"><div class="label">WiFi RSSI</div><div id="wifiSignal" class="value">-</div><div id="wifiIp" class="small">IP -</div></div>
          <div class="card"><div class="label">Last Send ms</div><div id="sendMs" class="value">-</div></div>
        </div>
        <div class="grid3" style="margin-top:10px">
          <div class="card"><div class="label">LoRaWAN Sent / OK / Fail</div><div id="lorawanCount" class="value small">-</div></div>
          <div class="card"><div class="label">MQTT Sent / OK / Fail</div><div id="mqttCount" class="value small">-</div></div>
          <div class="card"><div class="label">Retry</div><div id="retryCount" class="value small">-</div></div>
        </div>
        <div class="grid3" style="margin-top:10px">
          <div class="card"><div class="label">Link Mode</div><div id="linkMode" class="value small">-</div></div>
          <button onclick="cmd('SET LINK WIFI')">Demo: force WiFi fallback</button>
          <button class="secondary" onclick="cmd('SET LINK AUTO')">Auto: LoRaWAN first</button>
        </div>
        <div class="card" style="margin-top:10px">
            <div class="label">MQTT Topic</div>
          <div id="mqttTopic" class="small">-</div>
        </div>
      </section>
      <section style="margin-top:18px">
        <h2>Downlink Command</h2>
        <div class="grid">
          <div class="card"><div class="label">Last Time</div><div id="downlinkTime" class="value">-</div></div>
          <div class="card"><div class="label">Action</div><div id="downlinkAction" class="value">-</div></div>
        </div>
        <div class="card" style="margin-top:10px">
          <div class="label">Topic</div>
          <div id="downlinkTopic" class="small">-</div>
        </div>
        <div class="card" style="margin-top:10px">
          <div class="label">Payload</div>
          <div id="downlinkPayload" class="small">-</div>
        </div>
      </section>
      <section style="margin-top:18px">
        <h2>Actuator Control</h2>
        <div class="grid">
          <div class="card"><div class="label">Motor</div><div id="motorStatus" class="value">-</div></div>
          <div class="card"><div class="label">Angle</div><div id="servoAngle" class="value">-</div></div>
          <div class="card"><div class="label">LED</div><div id="ledStatus" class="value">-</div></div>
        </div>
        <div class="row2">
          <button onclick="cmd('MOTOR ON')">Start motor</button>
          <button class="secondary" onclick="cmd('MOTOR OFF')">Stop motor</button>
        </div>
        <div class="row2">
          <button onclick="cmd('LED ON')">LED on</button>
          <button class="secondary" onclick="cmd('LED OFF')">LED off</button>
        </div>
      </section>
    </div>
    <section>
      <h2>Live Serial Log</h2>
      <pre id="log"></pre>
    </section>
  </main>
  <script>
    let lastCount = 0;
    async function refresh() {
      const res = await fetch('/api/state');
      const data = await res.json();
      const s = data.state;
      document.getElementById('seq').textContent = s.last_seq ?? '-';
      document.getElementById('boot').textContent = s.boot_id ?? '-';
      const fmt1 = v => v == null ? '-' : Number(v).toFixed(1);
      document.getElementById('temp').textContent = fmt1(s.temperature) + (s.temperature == null ? '' : ' C');
      document.getElementById('humi').textContent = fmt1(s.humidity) + (s.humidity == null ? '' : ' %');
      document.getElementById('soil').textContent = fmt1(s.soil_moisture) + (s.soil_moisture == null ? '' : ' %');
      document.getElementById('soilRaw').textContent = 'raw ' + (s.soil_raw ?? '-');
      document.getElementById('rain').textContent = fmt1(s.rain_level) + (s.rain_level == null ? '' : ' %');
      document.getElementById('rainRaw').textContent = 'raw ' + (s.rain_raw ?? '-');
      document.getElementById('lorawan').textContent = s.lorawan;
      document.getElementById('mqtt').textContent = s.mqtt;
      document.getElementById('lorawanRadio').textContent =
        (s.uplink_freq == null ? '-' : Number(s.uplink_freq).toFixed(3) + ' MHz') +
        ' / DR' + (s.uplink_dr ?? '-');
      document.getElementById('downlink').textContent =
        s.downlink_bytes == null ? '-' : s.downlink_bytes + ' B';
      document.getElementById('wifiSignal').textContent =
        s.wifi_signal == null ? '-' : s.wifi_signal + ' dBm';
      document.getElementById('wifiIp').textContent =
        'IP ' + (s.wifi_ip ?? '-') + ' / GW ' + (s.wifi_gateway ?? '-');
      document.getElementById('sendMs').textContent = s.send_time_ms ?? '-';
      document.getElementById('lorawanCount').textContent =
        `${s.lorawan_sent} / ${s.lorawan_ok} / ${s.lorawan_failed}`;
      document.getElementById('mqttCount').textContent =
        `${s.mqtt_sent} / ${s.mqtt_ok} / ${s.mqtt_failed}`;
      document.getElementById('retryCount').textContent =
        `LoRa ${s.lorawan_retry_count ?? '-'} / WiFi ${s.wifi_retry_count ?? '-'}`;
      document.getElementById('linkMode').textContent = s.link_mode || '-';
      document.getElementById('mqttTopic').textContent = s.mqtt_topic || '-';
      document.getElementById('downlinkTime').textContent = s.downlink_time || '-';
      document.getElementById('downlinkAction').textContent = s.downlink_action || '-';
      document.getElementById('downlinkTopic').textContent = s.downlink_topic || '-';
      document.getElementById('downlinkPayload').textContent = s.downlink_payload || '-';
      document.getElementById('motorStatus').textContent = s.motor_status || '-';
      document.getElementById('servoAngle').textContent =
        s.servo_angle == null ? '-' : s.servo_angle + ' deg';
      document.getElementById('ledStatus').textContent = s.led_status || '-';
      const lines = data.logs.map(x => `[${x.time}] ${x.line}`).join('\\n');
      const box = document.getElementById('log');
      box.textContent = lines;
      if (data.logs.length !== lastCount) {
        box.scrollTop = box.scrollHeight;
        lastCount = data.logs.length;
      }
    }
    async function cmd(command) {
      await fetch('/api/command', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({command})
      });
      setTimeout(refresh, 200);
    }
    setInterval(refresh, 1000);
    refresh();
  </script>
</body>
</html>
"""


@app.route("/api/state")
def api_state():
    return jsonify({"state": state, "logs": list(logs)})


@app.route("/api/command", methods=["POST"])
def api_command():
    data = request.get_json(force=True)
    command = data.get("command", "").strip()
    if not command:
        return jsonify({"ok": False, "error": "empty command"}), 400
    try:
        send_command(command)
        return jsonify({"ok": True})
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500


def main():
    global ser
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", default="COM8")
    parser.add_argument("--baud", default=115200, type=int)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--web-port", default=5000, type=int)
    args = parser.parse_args()

    state["port"] = args.port
    ser = serial.Serial(args.port, args.baud, timeout=0.2)
    state["connected"] = True
    add_log(f"[CONSOLE] connected to {args.port} @ {args.baud}")

    thread = threading.Thread(target=serial_reader, daemon=True)
    thread.start()
    time.sleep(0.5)
    send_command("STATUS")

    app.run(host=args.host, port=args.web_port, debug=False, use_reloader=False, threaded=True)


if __name__ == "__main__":
    main()


