#include <RadioLib.h>
#include <WiFi.h>
#include <PubSubClient.h>
#include <DHT.h>
#include <Preferences.h>
#include <time.h>
#include "boards.h"

#if defined(USING_SX1268_433M)
SX1268 radio = new Module(RADIO_CS_PIN, RADIO_DIO1_PIN, RADIO_RST_PIN, RADIO_BUSY_PIN);
#else
#error "This example is prepared for EoRa-S3-400TB / SX1268."
#endif

// ChirpStack OTAA parameters.
static uint64_t joinEUI = 0x0000000000000000;
static uint64_t devEUI  = 0x0000000000000925;
static uint8_t appKey[] = {
  0xf0, 0x66, 0x75, 0xca, 0x59, 0x6f, 0xdb, 0x5c,
  0x54, 0xc6, 0x3b, 0x4d, 0x6f, 0x82, 0x74, 0x8e
};
// ChirpStack/LoRaWAN 1.0.x often only has AppKey. RadioLib accepts NwkKey too;
// keep it equal to AppKey for compatibility with the OTAA starter flow.
static uint8_t nwkKey[] = {
  0xf0, 0x66, 0x75, 0xca, 0x59, 0x6f, 0xdb, 0x5c,
  0x54, 0xc6, 0x3b, 0x4d, 0x6f, 0x82, 0x74, 0x8e
};

// HUB OneChannel listens at CN470 channel 1: 470.500 MHz, SF7, BW125.
// CN470 subBand 1 enables channels 0-7. This test keeps only channel 1 enabled.
static const LoRaWANBand_t Region = CN470;
static const uint8_t subBand = 1;
static const uint16_t hubChannelMask = 0x0002;  // channel 1 = 470.500 MHz.
static const uint32_t retryJoinSeconds = 30;
static const uint32_t uplinkIntervalSeconds = 5;
static const uint32_t sensorPreviewIntervalMs = 5000;
static const uint32_t retryUplinkDelayMs = 5000;
static const uint8_t maxUplinkRetries = 2;
static const uint8_t appPort = 2;
static const char *lorawanPrefsNamespace = "lorawan";
static const char *lorawanNoncesKey = "nonces";
static const char *lorawanSessionKey = "session";

static const char *wifiSsid = "Cudy-Boy";
static const char *wifiPassword = "1234567890";
static const char *mqttBroker = "192.168.200.221";
static const uint16_t mqttPort = 1883;
static const char *mqttTopic = "bridge/uplink/generic/eora_s3_400tb_001/data";
static const char *mqttDownlinkTopic = "bridge/downlink/generic/eora_s3_400tb_001/cmd";
static const char *deviceId = "eora_s3_400tb_001";
static const uint32_t wifiConnectTimeoutMs = 20000;
static const uint32_t retryMqttDelayMs = 3000;
static const uint32_t mqttMaintainIntervalMs = 10000;
static const uint8_t maxMqttRetries = 2;

// Aosong AM2302 / DHT22 air temperature and humidity sensor:
// VCC -> 3.3V VDD, GND -> GND, OUT -> GPIO16.
static const uint8_t am2302DataPin = 16;
static const uint8_t am2302Type = DHT22;

// FC-28 soil moisture sensor:
// VCC -> 3.3V VDD, GND -> GND, AO -> GPIO15.
static const uint8_t soilAdcPin = 15;
static const uint16_t soilDryRaw = 3300;  // Calibrate in dry air/dry soil.
static const uint16_t soilWetRaw = 1200;  // Calibrate in wet soil/water.

// FC-37 rain / water drop sensor:
// VCC -> 3.3V VDD, GND -> GND, AO -> GPIO12. DO is not used for now.
static const uint8_t rainAdcPin = 12;
static const uint16_t rainDryRaw = 3300;  // Calibrate when the plate is dry.
static const uint16_t rainWetRaw = 1200;  // Calibrate when the plate is wet.

// SG90 9g servo:
// Red -> 5V/VCC, Brown/Black -> GND, Orange/Yellow -> GPIO35.
static const uint8_t servoPin = 35;
static const uint16_t servoMinPulseUs = 1000;
static const uint16_t servoMaxPulseUs = 2000;
static const uint16_t servoHoldMs = 700;
static const uint16_t servoStepIntervalMs = 35;
static const uint8_t servoStepDegrees = 3;

// On-board controllable LED. The official EoRa PI examples define BOARD_LED as
// GPIO37. GPIO8 is already used as the LoRa radio reset pin in this project.
#ifdef BOARD_LED
static const uint8_t ledPin = BOARD_LED;
#else
static const uint8_t ledPin = 37;
#endif

LoRaWANNode node(&radio, &Region, subBand);
DHT am2302(am2302DataPin, am2302Type);
WiFiClient wifiClient;
PubSubClient mqttClient(wifiClient);
Preferences lorawanPrefs;
static bool joined = false;
static uint16_t seq = 0;
static uint32_t bootId = 0;
static bool manualDataMode = false;
static bool paused = false;
static bool forceSend = false;
static bool forceWifiFallbackDemo = false;
static int16_t manualTemp10 = 260;
static uint16_t manualHumi10 = 550;
static uint32_t currentUplinkIntervalSeconds = uplinkIntervalSeconds;
static uint32_t nextUplinkMs = 0;
static uint32_t lastSensorPreviewMs = 0;
static uint32_t lastMqttMaintainMs = 0;
static uint8_t servoAngle = 0;
static bool servoRunning = false;
static int8_t servoDirection = 1;
static uint32_t lastServoStepMs = 0;
static bool ledOn = false;
static char lastCommandName[16] = "none";
static char lastCommandSource[12] = "none";
static char lastCommandResult[12] = "none";
static uint8_t lastCommandTarget = 0;
static uint8_t lastCommandValue = 0;
static uint16_t commandCounter = 0;
static String serialLine;
static bool timeSyncStarted = false;

void showStatus(const char *line1, const char *line2, int16_t code = 0) {
#ifdef HAS_DISPLAY
  if (u8g2) {
    char buf[24];
    u8g2->clearBuffer();
    u8g2->setFont(u8g2_font_ncenB08_tr);
    u8g2->drawStr(0, 12, line1);
    u8g2->drawStr(0, 28, line2);
    if (code != 0) {
      snprintf(buf, sizeof(buf), "code=%d", code);
      u8g2->drawStr(0, 44, buf);
    }
    u8g2->sendBuffer();
  }
#else
  (void)line1;
  (void)line2;
  (void)code;
#endif
}

void printState(const char *label, int16_t state) {
  Serial.print(label);
  Serial.print(F(": "));
  Serial.println(state);
}

uint16_t clampU16(int32_t value, uint16_t low, uint16_t high) {
  if (value < low) {
    return low;
  }
  if (value > high) {
    return high;
  }
  return (uint16_t)value;
}

void writeServoPulse(uint16_t pulseUs) {
  digitalWrite(servoPin, HIGH);
  delayMicroseconds(pulseUs);
  digitalWrite(servoPin, LOW);
  delayMicroseconds(20000 - pulseUs);
}

void holdServoPulse(uint16_t pulseUs, uint16_t holdMs) {
  uint32_t startMs = millis();
  while (millis() - startMs < holdMs) {
    writeServoPulse(pulseUs);
  }
}

uint16_t servoPulseFromAngle(uint8_t angle) {
  if (angle > 180) {
    angle = 180;
  }
  return servoMinPulseUs +
         ((uint32_t)(servoMaxPulseUs - servoMinPulseUs) * angle / 180);
}

void setServoAngle(uint8_t angle) {
  if (angle > 180) {
    angle = 180;
  }
  servoRunning = false;
  servoAngle = angle;
  uint16_t pulseUs = servoPulseFromAngle(angle);
  holdServoPulse(pulseUs, servoHoldMs);

  Serial.print(F("[SERVO] angle="));
  Serial.print(servoAngle);
  Serial.print(F(" status="));
  Serial.println(F("stopped"));
}

void startServoMotor() {
  if (!servoRunning) {
    servoRunning = true;
    lastServoStepMs = millis();
    Serial.print(F("[SERVO] angle="));
    Serial.print(servoAngle);
    Serial.println(F(" status=running"));
  }
}

void stopServoMotor() {
  if (servoRunning) {
    servoRunning = false;
    digitalWrite(servoPin, LOW);
    Serial.print(F("[SERVO] angle="));
    Serial.print(servoAngle);
    Serial.println(F(" status=stopped"));
  }
}

void serviceServoMotor() {
  if (!servoRunning) {
    return;
  }

  uint32_t now = millis();
  if (now - lastServoStepMs >= servoStepIntervalMs) {
    lastServoStepMs = now;
    int16_t nextAngle = (int16_t)servoAngle + servoDirection * servoStepDegrees;
    if (nextAngle >= 180) {
      nextAngle = 180;
      servoDirection = -1;
    } else if (nextAngle <= 0) {
      nextAngle = 0;
      servoDirection = 1;
    }
    servoAngle = (uint8_t)nextAngle;
  }

  writeServoPulse(servoPulseFromAngle(servoAngle));
}

void setLedState(bool on) {
  ledOn = on;
#ifdef LED_ON
  digitalWrite(ledPin, on ? LED_ON : !LED_ON);
#else
  digitalWrite(ledPin, on ? HIGH : LOW);
#endif

  Serial.print(F("[LED] status="));
  Serial.println(ledOn ? F("on") : F("off"));
}

void rememberCommandAck(const char *source, const char *name,
                        uint8_t target, uint8_t value,
                        const char *result) {
  snprintf(lastCommandSource, sizeof(lastCommandSource), "%s", source);
  snprintf(lastCommandName, sizeof(lastCommandName), "%s", name);
  snprintf(lastCommandResult, sizeof(lastCommandResult), "%s", result);
  lastCommandTarget = target;
  lastCommandValue = value;
  commandCounter++;

  Serial.print(F("[CMD/ACK] source="));
  Serial.print(lastCommandSource);
  Serial.print(F(" cmd="));
  Serial.print(lastCommandName);
  Serial.print(F(" value="));
  Serial.print(lastCommandValue);
  Serial.print(F(" result="));
  Serial.print(lastCommandResult);
  Serial.print(F(" counter="));
  Serial.println(commandCounter);
}

uint8_t commandSourceCode() {
  if (strcmp(lastCommandSource, "serial") == 0) return 1;
  if (strcmp(lastCommandSource, "mqtt") == 0) return 2;
  if (strcmp(lastCommandSource, "lorawan") == 0) return 3;
  return 0;
}

uint8_t commandResultCode() {
  if (strcmp(lastCommandResult, "ok") == 0) return 1;
  if (strcmp(lastCommandResult, "unsupported") == 0) return 2;
  return 0;
}

uint16_t readSoilRaw() {
  uint32_t total = 0;
  const uint8_t samples = 8;
  for (uint8_t i = 0; i < samples; i++) {
    total += analogRead(soilAdcPin);
    delay(2);
  }
  return total / samples;
}

uint16_t soilRawToPercent10(uint16_t raw) {
  if (soilDryRaw == soilWetRaw) {
    return 0;
  }

  int32_t percent10 = ((int32_t)soilDryRaw - raw) * 1000L /
                      ((int32_t)soilDryRaw - soilWetRaw);
  return clampU16(percent10, 0, 1000);
}

uint16_t readRainRaw() {
  uint32_t total = 0;
  const uint8_t samples = 8;
  for (uint8_t i = 0; i < samples; i++) {
    total += analogRead(rainAdcPin);
    delay(2);
  }
  return total / samples;
}

uint16_t rainRawToLevel10(uint16_t raw) {
  if (rainDryRaw == rainWetRaw) {
    return 0;
  }

  int32_t level10 = ((int32_t)rainDryRaw - raw) * 1000L /
                    ((int32_t)rainDryRaw - rainWetRaw);
  return clampU16(level10, 0, 1000);
}

bool readAm2302(int16_t *temp10, uint16_t *humi10) {
  float humidity = am2302.readHumidity();
  float temperature = am2302.readTemperature();

  if (isnan(humidity) || isnan(temperature)) {
    Serial.println(F("[AM2302] read failed, using fallback data"));
    return false;
  }

  if (humidity < 0.0f) humidity = 0.0f;
  if (humidity > 100.0f) humidity = 100.0f;
  *temp10 = (int16_t)(temperature * 10.0f);
  *humi10 = (uint16_t)(humidity * 10.0f);

  Serial.print(F("[AM2302] temp="));
  Serial.print(*temp10 / 10.0f, 1);
  Serial.print(F(" humi="));
  Serial.println(*humi10 / 10.0f, 1);
  return true;
}

void readSensorValues(int16_t *temp10, uint16_t *humi10,
                      uint16_t *soilRaw, uint16_t *soilPercent10,
                      uint16_t *rainRaw, uint16_t *rainLevel10) {
  *temp10 = manualTemp10;
  *humi10 = manualHumi10;
  if (!manualDataMode && !readAm2302(temp10, humi10)) {
    uint16_t previewSeq = seq + 1;
    *temp10 = (int16_t)(260 + (previewSeq % 15));   // 26.0 - 27.4 C fallback.
    *humi10 = (uint16_t)(550 + (previewSeq % 30));  // 55.0 - 57.9 % fallback.
  }

  *soilRaw = readSoilRaw();
  *soilPercent10 = soilRawToPercent10(*soilRaw);
  *rainRaw = readRainRaw();
  *rainLevel10 = rainRawToLevel10(*rainRaw);
}

void printSensorPreview() {
  int16_t temp10;
  uint16_t humi10;
  uint16_t soilRaw;
  uint16_t soilPercent10;
  uint16_t rainRaw;
  uint16_t rainLevel10;
  readSensorValues(&temp10, &humi10, &soilRaw, &soilPercent10, &rainRaw, &rainLevel10);

  Serial.print(F("[SENSOR] temp="));
  Serial.print(temp10 / 10.0f, 1);
  Serial.print(F(" humi="));
  Serial.print(humi10 / 10.0f, 1);
  Serial.print(F(" soil="));
  Serial.print(soilPercent10 / 10.0f, 1);
  Serial.print(F("% raw="));
  Serial.print(soilRaw);
  Serial.print(F(" rain="));
  Serial.print(rainLevel10 / 10.0f, 1);
  Serial.print(F("% raw="));
  Serial.println(rainRaw);
}

void connectWiFi() {
  if (WiFi.status() == WL_CONNECTED) {
    return;
  }

  Serial.print(F("[WiFi] connecting to "));
  Serial.println(wifiSsid);
  WiFi.mode(WIFI_STA);
  WiFi.begin(wifiSsid, wifiPassword);

  uint32_t startMs = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - startMs < wifiConnectTimeoutMs) {
    delay(500);
    Serial.print(F("."));
  }
  Serial.println();

  if (WiFi.status() == WL_CONNECTED) {
    Serial.print(F("[WiFi] connected, IP="));
    Serial.println(WiFi.localIP());
    if (!timeSyncStarted) {
      configTime(0, 0, "ntp.aliyun.com", "pool.ntp.org");
      timeSyncStarted = true;
      Serial.println(F("[WiFi] NTP sync started"));
    }
  } else {
    Serial.println(F("[WiFi] connect timeout"));
  }
}

uint64_t getTimestampMs() {
  time_t now = time(nullptr);
  if (now > 1700000000) {
    return ((uint64_t)now * 1000ULL) + (millis() % 1000);
  }
  return 0;
}

bool ensureMqttConnected() {
  if (mqttClient.connected()) {
    return true;
  }

  if (WiFi.status() != WL_CONNECTED) {
    connectWiFi();
  }
  if (WiFi.status() != WL_CONNECTED) {
    return false;
  }

  Serial.print(F("[WiFi] status="));
  Serial.print(WiFi.status());
  Serial.print(F(" IP="));
  Serial.print(WiFi.localIP());
  Serial.print(F(" gateway="));
  Serial.print(WiFi.gatewayIP());
  Serial.print(F(" rssi="));
  Serial.println(WiFi.RSSI());

  mqttClient.setServer(mqttBroker, mqttPort);
  char clientId[48];
  snprintf(clientId, sizeof(clientId), "eora-s3-%08lx", (unsigned long)bootId);

  Serial.print(F("[MQTT] connecting to "));
  Serial.print(mqttBroker);
  Serial.print(F(":"));
  Serial.println(mqttPort);

  if (mqttClient.connect(clientId)) {
    Serial.println(F("[MQTT] connected"));
    if (mqttClient.subscribe(mqttDownlinkTopic)) {
      Serial.print(F("[MQTT] subscribed "));
      Serial.println(mqttDownlinkTopic);
    } else {
      Serial.print(F("[MQTT] subscribe failed "));
      Serial.println(mqttDownlinkTopic);
    }
    return true;
  }

  Serial.print(F("[MQTT] connect failed, state="));
  Serial.println(mqttClient.state());
  return false;
}

void printControlStatus() {
  Serial.print(F("[CTRL] status mode="));
  Serial.print(manualDataMode ? F("manual") : F("auto"));
  Serial.print(F(" paused="));
  Serial.print(paused ? F("true") : F("false"));
  Serial.print(F(" interval_s="));
  Serial.print(currentUplinkIntervalSeconds);
  Serial.print(F(" manual_temp="));
  Serial.print(manualTemp10 / 10.0f, 1);
  Serial.print(F(" manual_humi="));
  Serial.print(manualHumi10 / 10.0f, 1);
  Serial.print(F(" servo_angle="));
  Serial.print(servoAngle);
  Serial.print(F(" led="));
  Serial.println(ledOn ? F("on") : F("off"));
}

void handleControlCommand(String cmd, const char *source = "serial") {
  cmd.trim();
  if (cmd.length() == 0) {
    return;
  }

  String upper = cmd;
  upper.toUpperCase();

  if (upper == "HELP") {
    Serial.println(F("[CTRL] commands: STATUS, PAUSE, RESUME, SEND NOW, SET MODE AUTO|MANUAL, SET LINK AUTO|WIFI, SET TEMP <c>, SET HUMI <percent>, SET DATA <c> <percent>, SET INTERVAL <sec>, MOTOR ON|OFF, LED ON|OFF"));
    return;
  }

  if (upper == "STATUS") {
    printControlStatus();
    return;
  }

  if (upper == "PAUSE") {
    paused = true;
    Serial.println(F("[CTRL] paused"));
    return;
  }

  if (upper == "RESUME") {
    paused = false;
    nextUplinkMs = millis();
    Serial.println(F("[CTRL] resumed"));
    return;
  }

  if (upper == "SEND NOW") {
    forceSend = true;
    Serial.println(F("[CTRL] send requested"));
    return;
  }

  if (upper == "SET MODE AUTO") {
    manualDataMode = false;
    Serial.println(F("[CTRL] mode auto"));
    return;
  }

  if (upper == "SET MODE MANUAL") {
    manualDataMode = true;
    Serial.println(F("[CTRL] mode manual"));
    return;
  }

  if (upper == "SET LINK WIFI" || upper == "LINK WIFI" || upper == "FORCE WIFI") {
    forceWifiFallbackDemo = true;
    nextUplinkMs = millis();
    Serial.println(F("[LINK] demo mode force WiFi fallback"));
    return;
  }

  if (upper == "SET LINK AUTO" || upper == "LINK AUTO" || upper == "FORCE AUTO") {
    forceWifiFallbackDemo = false;
    nextUplinkMs = millis();
    Serial.println(F("[LINK] demo mode auto"));
    return;
  }

  if (upper == "MOTOR ON") {
    startServoMotor();
    rememberCommandAck(source, "motor_on", 0x02, 0x01, "ok");
    return;
  }

  if (upper == "MOTOR OFF") {
    stopServoMotor();
    rememberCommandAck(source, "motor_off", 0x02, 0x00, "ok");
    return;
  }

  if (upper == "LED ON") {
    setLedState(true);
    rememberCommandAck(source, "led_on", 0x01, 0x01, "ok");
    return;
  }

  if (upper == "LED OFF") {
    setLedState(false);
    rememberCommandAck(source, "led_off", 0x01, 0x00, "ok");
    return;
  }

  float temp = 0.0f;
  float humi = 0.0f;
  unsigned long interval = 0;
  unsigned long angle = 0;

  if (sscanf(cmd.c_str(), "SET TEMP %f", &temp) == 1 ||
      sscanf(cmd.c_str(), "set temp %f", &temp) == 1) {
    manualTemp10 = (int16_t)(temp * 10.0f);
    manualDataMode = true;
    Serial.print(F("[CTRL] manual temp="));
    Serial.println(manualTemp10 / 10.0f, 1);
    return;
  }

  if (sscanf(cmd.c_str(), "SET HUMI %f", &humi) == 1 ||
      sscanf(cmd.c_str(), "set humi %f", &humi) == 1) {
    if (humi < 0.0f) humi = 0.0f;
    if (humi > 100.0f) humi = 100.0f;
    manualHumi10 = (uint16_t)(humi * 10.0f);
    manualDataMode = true;
    Serial.print(F("[CTRL] manual humi="));
    Serial.println(manualHumi10 / 10.0f, 1);
    return;
  }

  if (sscanf(cmd.c_str(), "SET DATA %f %f", &temp, &humi) == 2 ||
      sscanf(cmd.c_str(), "set data %f %f", &temp, &humi) == 2) {
    if (humi < 0.0f) humi = 0.0f;
    if (humi > 100.0f) humi = 100.0f;
    manualTemp10 = (int16_t)(temp * 10.0f);
    manualHumi10 = (uint16_t)(humi * 10.0f);
    manualDataMode = true;
    Serial.print(F("[CTRL] manual data temp="));
    Serial.print(manualTemp10 / 10.0f, 1);
    Serial.print(F(" humi="));
    Serial.println(manualHumi10 / 10.0f, 1);
    return;
  }

  if (sscanf(cmd.c_str(), "SET INTERVAL %lu", &interval) == 1 ||
      sscanf(cmd.c_str(), "set interval %lu", &interval) == 1) {
    if (interval < 5) {
      interval = 5;
    }
    currentUplinkIntervalSeconds = (uint32_t)interval;
    Serial.print(F("[CTRL] interval_s="));
    Serial.println(currentUplinkIntervalSeconds);
    return;
  }

  if (sscanf(cmd.c_str(), "SET SERVO %lu", &angle) == 1 ||
      sscanf(cmd.c_str(), "set servo %lu", &angle) == 1) {
    if (angle > 180) {
      angle = 180;
    }
    setServoAngle((uint8_t)angle);
    return;
  }

  Serial.print(F("[CTRL] unknown command: "));
  Serial.println(cmd);
}

bool extractJsonToken(const String &body, const char *key, String &out) {
  String pattern = String("\"") + key + "\"";
  int keyPos = body.indexOf(pattern);
  if (keyPos < 0) {
    return false;
  }

  int colon = body.indexOf(':', keyPos + pattern.length());
  if (colon < 0) {
    return false;
  }

  int pos = colon + 1;
  while (pos < (int)body.length() && isspace((unsigned char)body[pos])) {
    pos++;
  }

  if (pos >= (int)body.length()) {
    return false;
  }

  if (body[pos] == '"') {
    int end = body.indexOf('"', pos + 1);
    if (end < 0) {
      return false;
    }
    out = body.substring(pos + 1, end);
  } else {
    int end = pos;
    while (end < (int)body.length() && body[end] != ',' && body[end] != '}') {
      end++;
    }
    out = body.substring(pos, end);
  }

  out.trim();
  out.toLowerCase();
  return true;
}

bool valueMeansOn(const String &value) {
  return value == "on" || value == "1" || value == "true" ||
         value == "start" || value == "run" || value == "running";
}

bool valueMeansOff(const String &value) {
  return value == "off" || value == "0" || value == "false" ||
         value == "stop" || value == "stopped";
}

String commandFromTargetValue(const String &target, const String &value) {
  if (target == "led" || target == "light") {
    if (valueMeansOn(value)) return "LED ON";
    if (valueMeansOff(value)) return "LED OFF";
  }

  if (target == "motor" || target == "servo") {
    if (valueMeansOn(value)) return "MOTOR ON";
    if (valueMeansOff(value)) return "MOTOR OFF";
  }

  return "";
}

String commandFromPayload(const String &body) {
  String normalized = body;
  normalized.trim();
  normalized.toLowerCase();

  if (normalized == "led on") return "LED ON";
  if (normalized == "led off") return "LED OFF";
  if (normalized == "motor on" || normalized == "servo on") return "MOTOR ON";
  if (normalized == "motor off" || normalized == "servo off") return "MOTOR OFF";

  if (!normalized.startsWith("{")) {
    return "";
  }

  String cmd;
  String value;
  String target;
  String stateValue;

  extractJsonToken(normalized, "value", value);
  extractJsonToken(normalized, "state", stateValue);
  if (value.length() == 0) {
    value = stateValue;
  }

  if (extractJsonToken(normalized, "command", cmd) || extractJsonToken(normalized, "cmd", cmd)) {
    cmd.replace('_', ' ');
    cmd.replace('-', ' ');
    cmd.trim();

    if (cmd == "led on") return "LED ON";
    if (cmd == "led off") return "LED OFF";
    if (cmd == "motor on" || cmd == "servo on") return "MOTOR ON";
    if (cmd == "motor off" || cmd == "servo off") return "MOTOR OFF";

    String fromCmd = commandFromTargetValue(cmd, value);
    if (fromCmd.length() > 0) {
      return fromCmd;
    }
  }

  if (extractJsonToken(normalized, "target", target)) {
    String fromTarget = commandFromTargetValue(target, value);
    if (fromTarget.length() > 0) {
      return fromTarget;
    }
  }

  return "";
}

bool handleControlPayload(const String &body, const char *source) {
  String command = commandFromPayload(body);
  if (command.length() == 0) {
    return false;
  }

  handleControlCommand(command, source);
  return true;
}

void handleMqttDownlink(char *topic, uint8_t *payload, unsigned int length) {
  String body;
  body.reserve(length + 1);
  for (unsigned int i = 0; i < length; i++) {
    body += (char)payload[i];
  }

  Serial.print(F("[MQTT/DOWN] topic="));
  Serial.println(topic);
  Serial.print(F("[MQTT/DOWN] payload="));
  Serial.println(body);

  if (handleControlPayload(body, "mqtt")) {
    return;
  }

  Serial.println(F("[MQTT/DOWN] ignored non-command payload"));
}
void printHexByte(uint8_t value) {
  if (value < 0x10) {
    Serial.print('0');
  }
  Serial.print(value, HEX);
}

void handleLoRaWANDownlink(uint8_t *payload, size_t length) {
  if (length == 0) {
    return;
  }

  Serial.print(F("[LoRaWAN/DOWN] bytes="));
  Serial.println(length);
  Serial.print(F("[LoRaWAN/DOWN] hex="));
  for (size_t i = 0; i < length; i++) {
    printHexByte(payload[i]);
    if (i + 1 < length) {
      Serial.print(' ');
    }
  }
  Serial.println();

  // Binary command format:
  // [0] 0xA5 magic, [1] target, [2] value
  // target: 0x01 LED, 0x02 motor/servo
  // value:  0x00 off/stop, 0x01 on/start
  if (length >= 3 && payload[0] == 0xA5) {
    uint8_t target = payload[1];
    uint8_t value = payload[2];
    if (target == 0x01) {
      handleControlCommand(value ? "LED ON" : "LED OFF", "lorawan");
      return;
    }
    if (target == 0x02) {
      handleControlCommand(value ? "MOTOR ON" : "MOTOR OFF", "lorawan");
      return;
    }
    rememberCommandAck("lorawan", "unsupported", target, value, "unsupported");
    Serial.print(F("[LoRaWAN/DOWN] unsupported binary target="));
    Serial.println(target);
    return;
  }

  String body;
  bool printableOnly = true;
  body.reserve(length + 1);
  for (size_t i = 0; i < length; i++) {
    if (payload[i] >= 32 && payload[i] <= 126) {
      body += (char)payload[i];
    } else {
      printableOnly = false;
    }
  }

  if (printableOnly && body.length() > 0) {
    Serial.print(F("[LoRaWAN/DOWN] text="));
    Serial.println(body);

    if (handleControlPayload(body, "lorawan")) {
      return;
    }
  }

  rememberCommandAck("lorawan", "unsupported", 0x00, 0x00, "unsupported");
  Serial.println(F("[LoRaWAN/DOWN] unsupported command"));}

void handleSerialCommands() {
  while (Serial.available() > 0) {
    char c = (char)Serial.read();
    if (c == '\r') {
      continue;
    }
    if (c == '\n') {
      handleControlCommand(serialLine);
      serialLine = "";
      continue;
    }
    if (serialLine.length() < 96) {
      serialLine += c;
    }
  }
}

void maintainMqtt() {
  if (millis() - lastMqttMaintainMs < mqttMaintainIntervalMs) {
    return;
  }
  lastMqttMaintainMs = millis();
  if (!mqttClient.connected()) {
    ensureMqttConnected();
  }
}

void lockUplinkToHubChannel() {
  node.channelMasks[0] = hubChannelMask;
  node.channelFlags[0] = hubChannelMask;
  for (size_t i = 1; i < sizeof(node.channelMasks) / sizeof(node.channelMasks[0]); i++) {
    node.channelMasks[i] = 0;
    node.channelFlags[i] = 0;
  }
}

void putU16(uint8_t *payload, size_t offset, uint16_t value) {
  payload[offset] = (value >> 8) & 0xFF;
  payload[offset + 1] = value & 0xFF;
}

void putU32(uint8_t *payload, size_t offset, uint32_t value) {
  payload[offset] = (value >> 24) & 0xFF;
  payload[offset + 1] = (value >> 16) & 0xFF;
  payload[offset + 2] = (value >> 8) & 0xFF;
  payload[offset + 3] = value & 0xFF;
}

void putU64(uint8_t *payload, size_t offset, uint64_t value) {
  payload[offset] = (value >> 56) & 0xFF;
  payload[offset + 1] = (value >> 48) & 0xFF;
  payload[offset + 2] = (value >> 40) & 0xFF;
  payload[offset + 3] = (value >> 32) & 0xFF;
  payload[offset + 4] = (value >> 24) & 0xFF;
  payload[offset + 5] = (value >> 16) & 0xFF;
  payload[offset + 6] = (value >> 8) & 0xFF;
  payload[offset + 7] = value & 0xFF;
}

void buildReliabilityPayload(uint8_t *payload, uint16_t packetSeq,
                             uint32_t sendTimeMs, uint64_t timestampMs,
                             uint8_t retryCount,
                             int16_t temp10, uint16_t humi10,
                             uint16_t soilPercent10, uint16_t rainLevel10,
                             uint16_t soilRaw, uint16_t rainRaw,
                             uint8_t motorStatus, uint8_t currentServoAngle,
                             uint8_t currentLedStatus, int8_t signalRssi,
                             uint8_t flags) {
  // Payload v3 format, big-endian, 43 bytes:
  // 0 version, 1 flags, 2-3 seq, 4-7 boot_id, 8-11 send_time_ms,
  // 12-19 timestamp_ms, 20 lorawan_retry_count, 21-22 temp10,
  // 23-24 humi10, 25-26 soil_moisture10, 27-28 rain_level10,
  // 29-30 soil_raw, 31-32 rain_raw, 33 motor_status,
  // 34 servo_angle, 35 led_status, 36 signal_rssi,
  // 37-38 command_counter, 39 command_source, 40 command_target,
  // 41 command_value, 42 command_result.
  payload[0] = 3;
  payload[1] = flags;
  putU16(payload, 2, packetSeq);
  putU32(payload, 4, bootId);
  putU32(payload, 8, sendTimeMs);
  putU64(payload, 12, timestampMs);
  payload[20] = retryCount;
  putU16(payload, 21, (uint16_t)temp10);
  putU16(payload, 23, humi10);
  putU16(payload, 25, soilPercent10);
  putU16(payload, 27, rainLevel10);
  putU16(payload, 29, soilRaw);
  putU16(payload, 31, rainRaw);
  payload[33] = motorStatus;
  payload[34] = currentServoAngle;
  payload[35] = currentLedStatus;
  payload[36] = (uint8_t)signalRssi;
  putU16(payload, 37, commandCounter);
  payload[39] = commandSourceCode();
  payload[40] = lastCommandTarget;
  payload[41] = lastCommandValue;
  payload[42] = commandResultCode();
}

bool publishWifiMqtt(uint16_t packetSeq, uint32_t sendTimeMs,
                     uint8_t wifiRetryCount, int16_t temp10,
                     uint16_t humi10, uint16_t soilRaw,
                     uint16_t soilPercent10, uint16_t rainRaw,
                     uint16_t rainLevel10) {
  if (!ensureMqttConnected()) {
    return false;
  }

  uint64_t timestampMs = getTimestampMs();
  char json[1200];
  snprintf(json, sizeof(json),
           "{\"device_id\":\"%s\",\"name\":\"%s\",\"type\":\"multi\","
           "\"status\":\"online\",\"source\":\"generic\",\"timestamp\":%llu,"
           "\"temperature\":%.1f,\"humidity\":%.1f,"
           "\"soil_moisture\":%.1f,\"rain_level\":%.1f,"
           "\"motor_status\":\"%s\",\"servo_angle\":%u,"
           "\"led_status\":\"%s\","
           "\"last_cmd\":{\"name\":\"%s\",\"source\":\"%s\",\"result\":\"%s\","
           "\"target\":%u,\"value\":%u,\"counter\":%u},"
           "\"signal\":%d,"
           "\"raw\":{\"dev_eui\":\"0000000000000925\",\"boot_id\":%lu,"
           "\"seq\":%u,\"send_time_ms\":%lu,\"wifi_retry_count\":%u,"
           "\"soil_raw\":%u,\"rain_raw\":%u,\"link\":\"wifi\"}}",
           deviceId,
           deviceId,
           (unsigned long long)timestampMs,
           temp10 / 10.0f,
           humi10 / 10.0f,
           soilPercent10 / 10.0f,
           rainLevel10 / 10.0f,
           servoRunning ? "running" : "stopped",
           servoAngle,
           ledOn ? "on" : "off",
           lastCommandName,
           lastCommandSource,
           lastCommandResult,
           lastCommandTarget,
           lastCommandValue,
           commandCounter,
           WiFi.RSSI(),
           (unsigned long)bootId,
           packetSeq,
           (unsigned long)sendTimeMs,
           wifiRetryCount,
           soilRaw,
           rainRaw);

  Serial.print(F("[MQTT] publish topic="));
  Serial.println(mqttTopic);
  Serial.print(F("[MQTT] payload="));
  Serial.println(json);
  return mqttClient.publish(mqttTopic, json);
}

bool loadLoRaWANBuffer(const char *key, uint8_t *buffer, size_t expectedLen) {
  size_t savedLen = lorawanPrefs.getBytesLength(key);
  if (savedLen == 0) {
    Serial.print(F("[LoRaWAN/NVS] no saved "));
    Serial.println(key);
    return false;
  }
  if (savedLen != expectedLen) {
    Serial.print(F("[LoRaWAN/NVS] saved "));
    Serial.print(key);
    Serial.print(F(" length mismatch: "));
    Serial.print(savedLen);
    Serial.print(F(" expected "));
    Serial.println(expectedLen);
    return false;
  }

  size_t readLen = lorawanPrefs.getBytes(key, buffer, expectedLen);
  if (readLen != expectedLen) {
    Serial.print(F("[LoRaWAN/NVS] read "));
    Serial.print(key);
    Serial.println(F(" failed"));
    return false;
  }
  return true;
}

void restoreLoRaWANState() {
  uint8_t nonces[RADIOLIB_LORAWAN_NONCES_BUF_SIZE];
  uint8_t session[RADIOLIB_LORAWAN_SESSION_BUF_SIZE];

  if (loadLoRaWANBuffer(lorawanNoncesKey, nonces, sizeof(nonces))) {
    int16_t state = node.setBufferNonces(nonces);
    printState("[LoRaWAN/NVS] restore nonces", state);
  }

  if (loadLoRaWANBuffer(lorawanSessionKey, session, sizeof(session))) {
    int16_t state = node.setBufferSession(session);
    printState("[LoRaWAN/NVS] restore session", state);
  }
}

void saveLoRaWANState(const char *reason) {
  size_t noncesLen = lorawanPrefs.putBytes(lorawanNoncesKey, node.getBufferNonces(),
                                           RADIOLIB_LORAWAN_NONCES_BUF_SIZE);
  size_t sessionLen = lorawanPrefs.putBytes(lorawanSessionKey, node.getBufferSession(),
                                            RADIOLIB_LORAWAN_SESSION_BUF_SIZE);

  Serial.print(F("[LoRaWAN/NVS] saved after "));
  Serial.print(reason);
  Serial.print(F(" nonces="));
  Serial.print(noncesLen);
  Serial.print(F(" session="));
  Serial.println(sessionLen);
}

bool joinNetwork() {
  Serial.println(F("[LoRaWAN] OTAA join start"));
  showStatus("LoRaWAN", "Joining...");

  int16_t state = node.beginOTAA(joinEUI, devEUI, nwkKey, appKey);
  if (state != RADIOLIB_ERR_NONE) {
    printState("beginOTAA failed", state);
    showStatus("beginOTAA FAIL", "check keys", state);
    return false;
  }

  restoreLoRaWANState();

  state = node.activateOTAA();
  if (state != RADIOLIB_LORAWAN_NEW_SESSION && state != RADIOLIB_LORAWAN_SESSION_RESTORED) {
    printState("activateOTAA failed", state);
    showStatus("Join failed", "wait server", state);
    return false;
  }

  saveLoRaWANState("join");

  node.setADR(false);
  state = node.setDatarate(5);  // CN470 DR5 = SF7 / BW125.
  printState("setDatarate DR5", state);
  state = node.setTxPower(19);
  printState("setTxPower 19dBm", state);
  lockUplinkToHubChannel();
  Serial.println(F("[LoRaWAN] uplink locked to 470.500 MHz"));

  Serial.println(F("[LoRaWAN] joined"));
  showStatus("LoRaWAN", "Joined OK");
  return true;
}

bool sendTelemetry() {
  seq++;
  int16_t temp10;
  uint16_t humi10;
  uint16_t soilRaw;
  uint16_t soilPercent10;
  uint16_t rainRaw;
  uint16_t rainLevel10;
  readSensorValues(&temp10, &humi10, &soilRaw, &soilPercent10, &rainRaw, &rainLevel10);
  int16_t state = RADIOLIB_ERR_NONE;
  bool uplinkOk = false;
  uint32_t firstSendTimeMs = 0;
  uint8_t downlink[64];
  size_t downlinkLen = 0;
  LoRaWANEvent_t uplinkDetails;
  LoRaWANEvent_t downlinkDetails;

  if (forceWifiFallbackDemo) {
    firstSendTimeMs = millis();
    Serial.println(F("[LINK] demo force WiFi fallback, skip LoRaWAN uplink"));
  } else {

  for (uint8_t retryCount = 0; retryCount <= maxUplinkRetries; retryCount++) {
    uint8_t payload[43];
    uint8_t flags = 0x01;  // bit0: joined.
    if (retryCount > 0) {
      flags |= 0x08;       // bit3: application-layer retry.
    }
    if (servoRunning) {
      flags |= 0x02;       // bit1: motor running.
    }
    if (ledOn) {
      flags |= 0x04;       // bit2: LED on.
    }

    uint32_t sendTimeMs = millis();
    uint64_t timestampMs = getTimestampMs();
    int8_t signalRssi = WiFi.isConnected() ? (int8_t)WiFi.RSSI() : 127;
    if (retryCount == 0) {
      firstSendTimeMs = sendTimeMs;
    }
    buildReliabilityPayload(payload, seq, sendTimeMs, timestampMs, retryCount,
                            temp10, humi10, soilPercent10, rainLevel10,
                            soilRaw, rainRaw, servoRunning ? 1 : 0, servoAngle,
                            ledOn ? 1 : 0, signalRssi, flags);

    Serial.print(F("[LoRaWAN] uplink seq="));
    Serial.print(seq);
    Serial.print(F(" boot="));
    Serial.print(bootId);
    Serial.print(F(" send_ms="));
    Serial.print(sendTimeMs);
    Serial.print(F(" retry="));
    Serial.print(retryCount);
    Serial.print(F(" temp="));
    Serial.print(temp10 / 10.0f, 1);
    Serial.print(F(" humi="));
    Serial.print(humi10 / 10.0f, 1);
    Serial.print(F(" soil="));
    Serial.print(soilPercent10 / 10.0f, 1);
    Serial.print(F("% raw="));
    Serial.print(soilRaw);
    Serial.print(F(" rain="));
    Serial.print(rainLevel10 / 10.0f, 1);
    Serial.print(F("% raw="));
    Serial.print(rainRaw);
    Serial.print(F(" motor="));
    Serial.print(servoRunning ? F("running") : F("stopped"));
    Serial.print(F(" servo_angle="));
    Serial.print(servoAngle);
    Serial.print(F(" led="));
    Serial.print(ledOn ? F("on") : F("off"));
    Serial.print(F(" signal="));
    Serial.println(signalRssi);
    char displayLine[24];
    snprintf(displayLine, sizeof(displayLine), "S%.1f R%.1f%%",
             soilPercent10 / 10.0f, rainLevel10 / 10.0f);
    showStatus("Sending uplink", displayLine);

    downlinkLen = sizeof(downlink);
    state = node.sendReceive(payload, sizeof(payload), appPort,
                             downlink, &downlinkLen, false,
                             &uplinkDetails, &downlinkDetails);

    Serial.print(F("[LoRaWAN] sendReceive state="));
    Serial.println(state);
    Serial.print(F("[LoRaWAN] uplink freq="));
    Serial.print(uplinkDetails.freq, 3);
    Serial.print(F(" MHz DR="));
    Serial.println(uplinkDetails.datarate);

    if (state >= RADIOLIB_ERR_NONE) {
      uplinkOk = true;
      saveLoRaWANState("uplink");
      break;
    }

    if (state == RADIOLIB_ERR_NETWORK_NOT_JOINED) {
      joined = false;
      break;
    }

    if (retryCount < maxUplinkRetries) {
      Serial.print(F("[LoRaWAN] retry same seq in "));
      Serial.print(retryUplinkDelayMs);
      Serial.println(F(" ms"));
      delay(retryUplinkDelayMs);
    }
  }

  if (!uplinkOk) {
    showStatus("Uplink failed", "see serial", state);
  } else if (state > 0) {
    Serial.print(F("[LoRaWAN] downlink bytes="));
    Serial.println(downlinkLen);
    handleLoRaWANDownlink(downlink, downlinkLen);
    showStatus("Uplink OK", "downlink recv");
  } else {
    showStatus("Uplink OK", "no downlink");
  }

  if (uplinkOk) {
    Serial.println(F("[LINK] LoRaWAN OK, skip WiFi MQTT fallback"));
    return true;
  }
  }

  if (forceWifiFallbackDemo) {
    showStatus("WiFi fallback", "demo mode");
    Serial.println(F("[LINK] LoRaWAN forced unavailable, try WiFi MQTT fallback"));
  } else {
    Serial.println(F("[LINK] LoRaWAN failed, try WiFi MQTT fallback"));
  }
  bool mqttOk = false;
  for (uint8_t wifiRetryCount = 0; wifiRetryCount <= maxMqttRetries; wifiRetryCount++) {
    mqttOk = publishWifiMqtt(seq, firstSendTimeMs, wifiRetryCount, temp10, humi10,
                              soilRaw, soilPercent10, rainRaw, rainLevel10);
    if (mqttOk) {
      Serial.print(F("[MQTT] publish OK retry="));
      Serial.println(wifiRetryCount);
      break;
    }
    Serial.print(F("[MQTT] publish failed retry="));
    Serial.println(wifiRetryCount);
    if (wifiRetryCount < maxMqttRetries) {
      delay(retryMqttDelayMs);
    }
  }

  mqttClient.loop();
  return false;
}

void sendWifiOnlyTelemetry() {
  seq++;
  int16_t temp10;
  uint16_t humi10;
  uint16_t soilRaw;
  uint16_t soilPercent10;
  uint16_t rainRaw;
  uint16_t rainLevel10;
  readSensorValues(&temp10, &humi10, &soilRaw, &soilPercent10, &rainRaw, &rainLevel10);

  uint32_t sendTimeMs = millis();
  Serial.print(F("[WiFiOnly] uplink seq="));
  Serial.print(seq);
  Serial.print(F(" boot="));
  Serial.print(bootId);
  Serial.print(F(" send_ms="));
  Serial.print(sendTimeMs);
  Serial.print(F(" temp="));
  Serial.print(temp10 / 10.0f, 1);
  Serial.print(F(" humi="));
  Serial.print(humi10 / 10.0f, 1);
  Serial.print(F(" soil="));
  Serial.print(soilPercent10 / 10.0f, 1);
  Serial.print(F("% raw="));
  Serial.print(soilRaw);
  Serial.print(F(" rain="));
  Serial.print(rainLevel10 / 10.0f, 1);
  Serial.print(F("% raw="));
  Serial.println(rainRaw);
  showStatus("WiFi MQTT", "LoRa join wait");

  bool mqttOk = false;
  for (uint8_t wifiRetryCount = 0; wifiRetryCount <= maxMqttRetries; wifiRetryCount++) {
    mqttOk = publishWifiMqtt(seq, sendTimeMs, wifiRetryCount, temp10, humi10,
                              soilRaw, soilPercent10, rainRaw, rainLevel10);
    if (mqttOk) {
      Serial.print(F("[MQTT] publish OK retry="));
      Serial.println(wifiRetryCount);
      break;
    }
    Serial.print(F("[MQTT] publish failed retry="));
    Serial.println(wifiRetryCount);
    if (wifiRetryCount < maxMqttRetries) {
      delay(retryMqttDelayMs);
    }
  }

  mqttClient.loop();
}

void setup() {
  initBoard();
  delay(1500);
  bootId = esp_random();

  Serial.println();
  Serial.println(F("EoRa-S3 LoRaWAN OTAA CN470"));
  Serial.println(F("DevEUI: 0000000000000925"));
  Serial.print(F("BootID: "));
  Serial.println(bootId);
  Serial.println(F("Target: 470.500 MHz, SF7, BW125"));
  showStatus("S3 LoRaWAN", "CN470 470.500");
  if (lorawanPrefs.begin(lorawanPrefsNamespace, false)) {
    Serial.println(F("[LoRaWAN/NVS] preferences opened"));
  } else {
    Serial.println(F("[LoRaWAN/NVS] preferences open failed"));
  }
  am2302.begin();
  pinMode(am2302DataPin, INPUT_PULLUP);
  Serial.print(F("AM2302 OUT pin: GPIO"));
  Serial.println(am2302DataPin);
  analogReadResolution(12);
  pinMode(soilAdcPin, INPUT);
  Serial.print(F("FC-28 AO pin: GPIO"));
  Serial.println(soilAdcPin);
  pinMode(rainAdcPin, INPUT);
  Serial.print(F("FC-37 AO pin: GPIO"));
  Serial.println(rainAdcPin);
  pinMode(servoPin, OUTPUT);
  digitalWrite(servoPin, LOW);
  pinMode(ledPin, OUTPUT);
  setLedState(false);
  Serial.print(F("SG90 servo signal pin: GPIO"));
  Serial.println(servoPin);
  Serial.print(F("Board LED pin: GPIO"));
  Serial.println(ledPin);
  setServoAngle(servoAngle);
  mqttClient.setCallback(handleMqttDownlink);
  Serial.println(F("[LINK] priority: LoRaWAN first, WiFi MQTT fallback only"));

  Serial.print(F("[SX1268] Initializing ... "));
  ConfigLoRa_t config;
  config.frequency = 470.5;
  int16_t state = radio.begin(config);
  if (state != RADIOLIB_ERR_NONE) {
    Serial.print(F("failed, code "));
    Serial.println(state);
    showStatus("Radio init FAIL", "SX1268", state);
    while (true) {
      delay(1000);
    }
  }
  Serial.println(F("success"));

  joined = joinNetwork();
  nextUplinkMs = millis();
}

void loop() {
  handleSerialCommands();
  serviceServoMotor();

  if (!joined) {
    maintainMqtt();
    Serial.print(F("[LoRaWAN] retry join in "));
    Serial.print(retryJoinSeconds);
    Serial.println(F(" seconds"));
    uint32_t waitStart = millis();
    while (millis() - waitStart < retryJoinSeconds * 1000UL) {
      handleSerialCommands();
      if (millis() - lastSensorPreviewMs >= sensorPreviewIntervalMs) {
        lastSensorPreviewMs = millis();
        printSensorPreview();
      }
      if (forceSend || (!paused && (int32_t)(millis() - nextUplinkMs) >= 0)) {
        bool manualSend = forceSend;
        forceSend = false;
        sendWifiOnlyTelemetry();
        if (!manualSend || !paused) {
          nextUplinkMs = millis() + currentUplinkIntervalSeconds * 1000UL;
        }
      }
      maintainMqtt();
      serviceServoMotor();
      mqttClient.loop();
      delay(5);
    }
    joined = joinNetwork();
    return;
  }

  if (forceSend || (!paused && (int32_t)(millis() - nextUplinkMs) >= 0)) {
    bool manualSend = forceSend;
    forceSend = false;
    sendTelemetry();
    if (!manualSend || !paused) {
      nextUplinkMs = millis() + currentUplinkIntervalSeconds * 1000UL;
    }
  }

  mqttClient.loop();
  delay(5);
}


