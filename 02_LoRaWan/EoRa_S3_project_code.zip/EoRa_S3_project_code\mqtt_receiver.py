﻿import json
import base64
import paho.mqtt.client as mqtt


# ==========================
# MQTT閰嶇疆
# ==========================

MQTT_HOST = "192.168.3.219"

MQTT_PORT = 1883


# 涓や釜鏁版嵁鍏ュ彛
MQTT_TOPICS = [
    ("application/+/device/+/event/up", 1),
    ("bridge/uplink/generic/eora_s3_400tb_001/data", 1),`r`n    ("s3/eora-s3-400tb-001/data", 1)
]


# ==========================
# LoRa Payload瑙ｆ瀽
# ==========================

def parse_payload(payload):

    if len(payload) != 16:
        print(
            "Payload闀垮害寮傚父:",
            len(payload)
        )
        return None


    seq = int.from_bytes(
        payload[0:2],
        byteorder="big"
    )


    boot_id = int.from_bytes(
        payload[2:6],
        byteorder="big"
    )


    send_time_ms = int.from_bytes(
        payload[6:10],
        byteorder="big"
    )


    retry_count = payload[10]


    temp_raw = int.from_bytes(
        payload[11:13],
        byteorder="big",
        signed=True
    )

    temperature = temp_raw / 10.0



    humi_raw = int.from_bytes(
        payload[13:15],
        byteorder="big"
    )

    humidity = humi_raw / 10.0



    flags = payload[15]


    joined = bool(
        flags & 0x01
    )


    app_retry = bool(
        flags & 0x08
    )


    return {

        "seq": seq,

        "boot_id": hex(boot_id),

        "send_time_ms":
            send_time_ms,

        "lorawan_retry_count":
            retry_count,

        "temperature":
            temperature,

        "humidity":
            humidity,

        "joined":
            joined,

        "application_retry":
            app_retry,

        "flags":
            hex(flags)

    }



# ==========================
# MQTT杩炴帴鍥炶皟
# ==========================

def on_connect(client, userdata, flags, rc):

    if rc == 0:

        print(
            "MQTT杩炴帴鎴愬姛"
        )


        client.subscribe(
            MQTT_TOPICS
        )


        print(
            "璁㈤槄Topic:"
        )


        for topic, qos in MQTT_TOPICS:
            print(
                " ",
                topic
            )


    else:

        print(
            "MQTT杩炴帴澶辫触:",
            rc
        )



# ==========================
# MQTT娑堟伅澶勭悊
# ==========================

def on_message(client, userdata, msg):


    print("\n========================")

    print(
        "Topic:"
    )

    print(
        msg.topic
    )


    try:

        data = json.loads(
            msg.payload.decode()
        )


    except Exception as e:

        print(
            "JSON瑙ｆ瀽澶辫触:",
            e
        )

        return



    # ==================================================
    # WiFi MQTT 鏁版嵁
    # ==================================================

    if msg.topic in ("bridge/uplink/generic/eora_s3_400tb_001/data", "s3/eora-s3-400tb-001/data"):


        print(
            "\n========== WiFi鏁版嵁 =========="
        )


        print(
            "璁惧:",
            data.get("device_id")
        )


        print(
            "DevEUI:",
            data.get("dev_eui")
        )


        print(
            "搴忓彿:",
            data.get("seq")
        )


        print(
            "Boot ID:",
            data.get("boot_id")
        )


        print(
            "鍙戦€佹椂闂?",
            data.get("send_time_ms"),
            "ms"
        )


        print(
            "娓╁害:",
            data.get("temperature"),
            "鈩?
        )


        print(
            "婀垮害:",
            data.get("humidity"),
            "%"
        )


        print(
            "WiFi閲嶄紶:",
            data.get("wifi_retry_count")
        )


        print(
            "閾捐矾:",
            data.get("link")
        )


        print(
            "============================"
        )


        return



    # ==================================================
    # LoRaWAN / ChirpStack 鏁版嵁
    # ==================================================

    if msg.topic.startswith(
        "application/"
    ):


        print(
            "\n========== LoRaWAN鏁版嵁 =========="
        )


        device_info = data.get(
            "deviceInfo",
            {}
        )


        print(
            "DevEUI:",
            device_info.get(
                "devEui"
            )
        )


        print(
            "璁惧:",
            device_info.get(
                "deviceName"
            )
        )



        print(
            "\n鏃堕棿:"
        )

        print(
            data.get(
                "time"
            )
        )



        rx_info = data.get(
            "rxInfo",
            []
        )


        if rx_info:


            rx = rx_info[0]


            print(
                "\n缃戝叧:"
            )


            print(
                "Gateway:",
                rx.get(
                    "gatewayId"
                )
            )


            print(
                "RSSI:",
                rx.get(
                    "rssi"
                )
            )


            print(
                "SNR:",
                rx.get(
                    "snr"
                )
            )

        payload_b64 = data.get(
            "data"
        )

        print(
            "\nBase64:"
        )

        print(
            payload_b64
        )

        payload = base64.b64decode(
            payload_b64
        )

        print(
            "\nHEX:"
        )

        print(
            payload.hex()
        )

        result = parse_payload(
            payload
        )


        if result:

            print(
                "\n======= LoRa瑙ｆ瀽缁撴灉 ======="
            )

            print(
                "娓╁害:",
                result["temperature"],
                "鈩?
            )

            print(
                "婀垮害:",
                result["humidity"],
                "%"
            )

            print(
                "搴忓彿:",
                result["seq"]
            )

            print(
                "Boot ID:",
                result["boot_id"]
            )

            print(
                "LoRaWAN閲嶄紶:",
                result["lorawan_retry_count"]
            )

            print(
                "宸插叆缃?",
                result["joined"]
            )

            print(
                "搴旂敤灞傞噸浼?",
                result["application_retry"]
            )

            print(
                "============================"
            )



# ==========================
# 涓荤▼搴?
# ==========================

client = mqtt.Client(
    mqtt.CallbackAPIVersion.VERSION1
)


client.on_connect = on_connect
client.on_message = on_message


print(
    "姝ｅ湪杩炴帴MQTT..."
)

client.connect(
    MQTT_HOST,
    MQTT_PORT,
    60
)

client.loop_forever()
